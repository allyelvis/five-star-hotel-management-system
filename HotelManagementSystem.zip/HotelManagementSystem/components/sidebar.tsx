import Link from "next/link"
import { Home, BedDouble, CalendarDays, Users, Utensils, Briefcase, CreditCard, BarChart } from 'lucide-react'

const navItems = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Rooms", href: "/rooms", icon: BedDouble },
  { name: "Reservations", href: "/reservations", icon: CalendarDays },
  { name: "Guests", href: "/guests", icon: Users },
  { name: "Restaurant", href: "/restaurant", icon: Utensils },
  { name: "Staff", href: "/staff", icon: Briefcase },
  { name: "Billing", href: "/billing", icon: CreditCard },
  { name: "Reports", href: "/reports", icon: BarChart },
]

export function Sidebar() {
  return (
    <div className="w-64 bg-white shadow-md">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-gray-800">Hotel Manager</h1>
      </div>
      <nav className="mt-6">
        {navItems.map((item) => (
          <Link
            key={item.name}
            href={item.href}
            className="flex items-center px-6 py-3 text-gray-600 hover:bg-gray-100"
          >
            <item.icon className="mr-3 h-5 w-5" />
            {item.name}
          </Link>
        ))}
      </nav>
    </div>
  )
}

