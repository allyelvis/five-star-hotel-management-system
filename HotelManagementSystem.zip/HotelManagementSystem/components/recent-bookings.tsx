import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const recentBookings = [
  {
    name: "Olivia Martin",
    email: "olivia.martin@email.com",
    roomNumber: "101",
  },
  {
    name: "Jackson Lee",
    email: "jackson.lee@email.com",
    roomNumber: "204",
  },
  {
    name: "Isabella Nguyen",
    email: "isabella.nguyen@email.com",
    roomNumber: "305",
  },
  {
    name: "William Kim",
    email: "william.kim@email.com",
    roomNumber: "402",
  },
  {
    name: "Sofia Davis",
    email: "sofia.davis@email.com",
    roomNumber: "508",
  },
]

export function RecentBookings() {
  return (
    <div className="space-y-8">
      {recentBookings.map((booking) => (
        <div key={booking.email} className="flex items-center">
          <Avatar className="h-9 w-9">
            <AvatarImage src="/avatars/01.png" alt="Avatar" />
            <AvatarFallback>{booking.name[0]}</AvatarFallback>
          </Avatar>
          <div className="ml-4 space-y-1">
            <p className="text-sm font-medium leading-none">{booking.name}</p>
            <p className="text-sm text-muted-foreground">{booking.email}</p>
          </div>
          <div className="ml-auto font-medium">Room {booking.roomNumber}</div>
        </div>
      ))}
    </div>
  )
}

