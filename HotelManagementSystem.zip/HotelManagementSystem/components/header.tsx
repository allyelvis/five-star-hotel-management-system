import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <header className="bg-white border-b px-4 py-3 flex items-center justify-between">
      <h2 className="text-lg font-semibold">Five-Star Hotel Management</h2>
      <div className="flex items-center space-x-4">
        <Avatar>
          <AvatarImage src="/avatars/01.png" alt="User" />
          <AvatarFallback>JD</AvatarFallback>
        </Avatar>
        <div>
          <p className="text-sm font-medium">John Doe</p>
          <p className="text-xs text-gray-500">Hotel Manager</p>
        </div>
        <Button variant="outline">Logout</Button>
      </div>
    </header>
  )
}

