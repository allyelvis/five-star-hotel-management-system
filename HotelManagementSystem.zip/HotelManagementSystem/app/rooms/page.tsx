import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const rooms = [
  { number: "101", type: "Standard", status: "Occupied", guest: "John Doe", checkOut: "2024-03-18" },
  { number: "102", type: "Deluxe", status: "Available", guest: null, checkOut: null },
  { number: "103", type: "Suite", status: "Cleaning", guest: null, checkOut: null },
  { number: "201", type: "Standard", status: "Maintenance", guest: null, checkOut: null },
  { number: "202", type: "Deluxe", status: "Available", guest: null, checkOut: null },
  { number: "203", type: "Suite", status: "Occupied", guest: "Jane Smith", checkOut: "2024-03-20" },
]

export default function RoomsPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Room Management</h1>
        <Button>Add New Room</Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {rooms.map((room) => (
          <Card key={room.number}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Room {room.number}</CardTitle>
              <Badge
                variant={
                  room.status === "Available"
                    ? "default"
                    : room.status === "Occupied"
                    ? "destructive"
                    : "secondary"
                }
              >
                {room.status}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-2">{room.type}</div>
              {room.guest && (
                <div className="text-sm text-gray-500">
                  <p>Guest: {room.guest}</p>
                  <p>Check-out: {room.checkOut}</p>
                </div>
              )}
              <div className="mt-4 flex space-x-2">
                <Button variant="outline" size="sm">Edit</Button>
                <Button variant="outline" size="sm">
                  {room.status === "Occupied" ? "Check-out" : "Assign"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

