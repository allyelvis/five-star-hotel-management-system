import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const reservations = [
  {
    id: "1",
    guestName: "John Doe",
    roomNumber: "101",
    checkIn: "2024-03-15",
    checkOut: "2024-03-18",
    status: "Confirmed",
  },
  {
    id: "2",
    guestName: "Jane Smith",
    roomNumber: "202",
    checkIn: "2024-03-16",
    checkOut: "2024-03-20",
    status: "Checked In",
  },
  {
    id: "3",
    guestName: "Bob Johnson",
    roomNumber: "305",
    checkIn: "2024-03-17",
    checkOut: "2024-03-19",
    status: "Pending",
  },
  {
    id: "4",
    guestName: "Alice Brown",
    roomNumber: "404",
    checkIn: "2024-03-18",
    checkOut: "2024-03-22",
    status: "Confirmed",
  },
  {
    id: "5",
    guestName: "Charlie Wilson",
    roomNumber: "505",
    checkIn: "2024-03-19",
    checkOut: "2024-03-21",
    status: "Cancelled",
  },
]

export default function ReservationsPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Reservations</h1>
        <Button>New Reservation</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Guest Name</TableHead>
            <TableHead>Room Number</TableHead>
            <TableHead>Check-in</TableHead>
            <TableHead>Check-out</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {reservations.map((reservation) => (
            <TableRow key={reservation.id}>
              <TableCell>{reservation.guestName}</TableCell>
              <TableCell>{reservation.roomNumber}</TableCell>
              <TableCell>{reservation.checkIn}</TableCell>
              <TableCell>{reservation.checkOut}</TableCell>
              <TableCell>
                <Badge
                  variant={
                    reservation.status === "Confirmed"
                      ? "default"
                      : reservation.status === "Checked In"
                      ? "success"
                      : reservation.status === "Pending"
                      ? "warning"
                      : "destructive"
                  }
                >
                  {reservation.status}
                </Badge>
              </TableCell>
              <TableCell>
                <Button variant="outline" size="sm">Edit</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

