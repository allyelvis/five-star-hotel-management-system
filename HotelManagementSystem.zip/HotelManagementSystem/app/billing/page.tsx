import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

const bills = [
  {
    id: "1",
    guestName: "John Doe",
    roomNumber: "101",
    checkIn: "2024-03-15",
    checkOut: "2024-03-18",
    totalAmount: 750.00,
    status: "Paid",
  },
  {
    id: "2",
    guestName: "Jane Smith",
    roomNumber: "202",
    checkIn: "2024-03-16",
    checkOut: "2024-03-20",
    totalAmount: 1200.00,
    status: "Pending",
  },
  {
    id: "3",
    guestName: "Bob Johnson",
    roomNumber: "305",
    checkIn: "2024-03-17",
    checkOut: "2024-03-19",
    totalAmount: 600.00,
    status: "Paid",
  },
  {
    id: "4",
    guestName: "Alice Brown",
    roomNumber: "404",
    checkIn: "2024-03-18",
    checkOut: "2024-03-22",
    totalAmount: 1000.00,
    status: "Overdue",
  },
  {
    id: "5",
    guestName: "Charlie Wilson",
    roomNumber: "505",
    checkIn: "2024-03-19",
    checkOut: "2024-03-21",
    totalAmount: 800.00,
    status: "Refunded",
  },
]

export default function BillingPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Billing Management</h1>
        <Button>Create New Invoice</Button>
      </div>
      <div className="flex justify-between items-center">
        <Input className="max-w-sm" placeholder="Search bills..." />
        <Button variant="outline">Export Billing Data</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Guest Name</TableHead>
            <TableHead>Room Number</TableHead>
            <TableHead>Check-in</TableHead>
            <TableHead>Check-out</TableHead>
            <TableHead>Total Amount</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {bills.map((bill) => (
            <TableRow key={bill.id}>
              <TableCell>{bill.guestName}</TableCell>
              <TableCell>{bill.roomNumber}</TableCell>
              <TableCell>{bill.checkIn}</TableCell>
              <TableCell>{bill.checkOut}</TableCell>
              <TableCell>${bill.totalAmount.toFixed(2)}</TableCell>
              <TableCell>
                <Badge
                  variant={
                    bill.status === "Paid"
                      ? "default"
                      : bill.status === "Pending"
                      ? "secondary"
                      : bill.status === "Overdue"
                      ? "destructive"
                      : "outline"
                  }
                >
                  {bill.status}
                </Badge>
              </TableCell>
              <TableCell>
                <Button variant="outline" size="sm">View Details</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

