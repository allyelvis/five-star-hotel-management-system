import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

const staff = [
  {
    id: "1",
    name: "Emma Thompson",
    position: "Front Desk Manager",
    department: "Front Office",
    status: "Active",
    joinDate: "2022-05-15",
  },
  {
    id: "2",
    name: "Michael Chen",
    position: "Head Chef",
    department: "Food & Beverage",
    status: "Active",
    joinDate: "2021-11-01",
  },
  {
    id: "3",
    name: "Sarah Johnson",
    position: "Housekeeping Supervisor",
    department: "Housekeeping",
    status: "On Leave",
    joinDate: "2023-02-10",
  },
  {
    id: "4",
    name: "David Rodriguez",
    position: "Maintenance Technician",
    department: "Maintenance",
    status: "Active",
    joinDate: "2022-09-20",
  },
  {
    id: "5",
    name: "Lisa Patel",
    position: "Event Coordinator",
    department: "Events",
    status: "Active",
    joinDate: "2023-06-05",
  },
]

export default function StaffPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Staff Management</h1>
        <Button>Add New Staff</Button>
      </div>
      <div className="flex justify-between items-center">
        <Input className="max-w-sm" placeholder="Search staff..." />
        <Button variant="outline">Export Staff List</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Position</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Join Date</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {staff.map((employee) => (
            <TableRow key={employee.id}>
              <TableCell>{employee.name}</TableCell>
              <TableCell>{employee.position}</TableCell>
              <TableCell>{employee.department}</TableCell>
              <TableCell>
                <Badge
                  variant={employee.status === "Active" ? "default" : "secondary"}
                >
                  {employee.status}
                </Badge>
              </TableCell>
              <TableCell>{employee.joinDate}</TableCell>
              <TableCell>
                <Button variant="outline" size="sm">View Details</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

